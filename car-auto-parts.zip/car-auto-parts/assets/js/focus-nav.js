( function( window, document ) {
  function car_auto_parts_keepFocusInMenu() {
    document.addEventListener( 'keydown', function( e ) {
      const car_auto_parts_nav = document.querySelector( '.sidenav' );
      if ( ! car_auto_parts_nav || ! car_auto_parts_nav.classList.contains( 'open' ) ) {
        return;
      }
      const elements = [...car_auto_parts_nav.querySelectorAll( 'input, a, button' )],
        car_auto_parts_lastEl = elements[ elements.length - 1 ],
        car_auto_parts_firstEl = elements[0],
        car_auto_parts_activeEl = document.activeElement,
        tabKey = e.keyCode === 9,
        shiftKey = e.shiftKey;
      if ( ! shiftKey && tabKey && car_auto_parts_lastEl === car_auto_parts_activeEl ) {
        e.preventDefault();
        car_auto_parts_firstEl.focus();
      }
      if ( shiftKey && tabKey && car_auto_parts_firstEl === car_auto_parts_activeEl ) {
        e.preventDefault();
        car_auto_parts_lastEl.focus();
      }
    } );
  }
  car_auto_parts_keepFocusInMenu();
} )( window, document );