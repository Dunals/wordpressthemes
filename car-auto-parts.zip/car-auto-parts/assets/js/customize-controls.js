( function( api ) {

	// Extends our custom "car-auto-parts" section.
	api.sectionConstructor['car-auto-parts'] = api.Section.extend( {

		// No events for this type of section.
		attachEvents: function () {},

		// Always make the section active.
		isContextuallyActive: function () {
			return true;
		}
	} );

} )( wp.customize );