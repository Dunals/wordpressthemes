<?php
/**
 * Template Name: Custom Home Page
 *
 * @package Car Auto Parts
 * @subpackage car_auto_parts
 */

get_header(); ?>

<main id="tp_content" role="main">
	<div>
		<?php do_action('car_auto_parts_before_slider'); ?>
		<?php get_template_part('template-parts/home/slider'); ?>
		<?php do_action('car_auto_parts_after_slider'); ?>
	</div>
	<div>
		<?php get_template_part('template-parts/home/services'); ?>
		<?php do_action('car_auto_parts_after_about_us'); ?>
		<?php get_template_part('template-parts/home/home-content'); ?>
		<?php do_action('car_auto_parts_after_home_content'); ?>
	</div>
</main>

<?php get_footer(); ?>