<?php

$car_auto_parts_tp_theme_css = '';

$car_auto_parts_tp_color_option = get_theme_mod('car_auto_parts_tp_color_option');

if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='button[type="submit"], .center1 .ring::before, .center2 .ring::before, .top-main, .top-header, .product-cart .cart-count, .inner_searchbox button[type="submit"], .main-navigation ul ul, .main-navigation ul.sub-menu li a, .main-navigation .menu > ul > li.highlight, .readmore-btn a, #slider .owl-nav button.owl-prev span,
#slider .owl-nav button.owl-next span, #courses-offer .course-color, .woocommerce ul.products li.product .button,
a.checkout-button.button.alt.wc-forward, .woocommerce ul.products li.product .onsale,.woocommerce span.onsale, .wc-block-cart__submit-container a,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, nav.woocommerce-MyAccount-navigation ul li, .wc-block-checkout__actions_row .wc-block-components-checkout-place-order-button, .page-numbers, .prev.page-numbers,
.next.page-numbers, span.meta-nav, .error-404 [type="submit"], #theme-sidebar .wp-block-search .wp-block-search__label:before,#theme-sidebar h3:before, #theme-sidebar h1.wp-block-heading:before, #theme-sidebar h2.wp-block-heading:before, #theme-sidebar h3.wp-block-heading:before,#theme-sidebar h4.wp-block-heading:before, #theme-sidebar h5.wp-block-heading:before, #theme-sidebar h6.wp-block-heading:before, #theme-sidebar button[type="submit"],
#footer button[type="submit"], #comments input[type="submit"], .site-info, .toggle-nav button, .toggle-nav i{';
$car_auto_parts_tp_theme_css .='background: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='.wc-block-components-product-badge{';
$car_auto_parts_tp_theme_css .='background: '.esc_attr($car_auto_parts_tp_color_option).'!important;';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='a,a:hover,#theme-sidebar .textwidget a,
#footer .textwidget a,
.comment-body a,
.entry-content a,
.entry-summary a,#main-content p a, .content-area a, .main-navigation .current_page_item a, .logo h1 a:hover, .logo p a:hover, .header-details i:hover, .main-navigation a:hover, .box-info i, #slider .inner_carousel h1 a:hover, #slider p.slidetop-text, #courses-offer h3 a:hover, .cat-inner-box:hover .mainserv-content h3 a, .cat-inner-box:hover .cours-price, .wp-block-search .wp-block-search__label,#theme-sidebar h3, #theme-sidebar h1.wp-block-heading, #theme-sidebar h2.wp-block-heading, #theme-sidebar h3.wp-block-heading,#theme-sidebar h4.wp-block-heading, #theme-sidebar h5.wp-block-heading, #theme-sidebar h6.wp-block-heading, #footer li a:hover, #theme-sidebar a:hover, #theme-sidebar .tagcloud a:hover,#sidebar p.wp-block-tag-cloud a:hover, .post_tag a:hover,#theme-sidebar .widget_tag_cloud a:hover, #footer li a:hover, #footer .tagcloud a:hover,#footer p.wp-block-tag-cloud a:hover{';
$car_auto_parts_tp_theme_css .='color: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='.center1, .center2, #about h2:before{';
$car_auto_parts_tp_theme_css .='border-top-color: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='.page-box, .singlepage-main, #theme-sidebar section{';
$car_auto_parts_tp_theme_css .='border-bottom-color: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='.center1, .center2, .page-box, .singlepage-main, #theme-sidebar section, .main-navigation .current_page_item a{';
$car_auto_parts_tp_theme_css .='border-left-color: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='.social-area:after{';
$car_auto_parts_tp_theme_css .='border-right-color: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='.wp-block-tag-cloud a:hover, #theme-sidebar .tagcloud a:hover,#sidebar p.wp-block-tag-cloud a:hover, .post_tag a:hover,#theme-sidebar .widget_tag_cloud a:hover, #footer .tagcloud a:hover,#footer p.wp-block-tag-cloud a:hover{';
$car_auto_parts_tp_theme_css .='border-color: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_color_option != false){
$car_auto_parts_tp_theme_css .='{';
$car_auto_parts_tp_theme_css .='outline-color: '.esc_attr($car_auto_parts_tp_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}

//preloader

$car_auto_parts_tp_preloader_color1_option = get_theme_mod('car_auto_parts_tp_preloader_color1_option');
$car_auto_parts_tp_preloader_color2_option = get_theme_mod('car_auto_parts_tp_preloader_color2_option');
$car_auto_parts_tp_preloader_bg_color_option = get_theme_mod('car_auto_parts_tp_preloader_bg_color_option');

if($car_auto_parts_tp_preloader_color1_option != false){
$car_auto_parts_tp_theme_css .='.center1{';
	$car_auto_parts_tp_theme_css .='border-color: '.esc_attr($car_auto_parts_tp_preloader_color1_option).' !important;';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_preloader_color1_option != false){
$car_auto_parts_tp_theme_css .='.center1 .ring::before{';
	$car_auto_parts_tp_theme_css .='background: '.esc_attr($car_auto_parts_tp_preloader_color1_option).' !important;';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_preloader_color2_option != false){
$car_auto_parts_tp_theme_css .='.center2{';
	$car_auto_parts_tp_theme_css .='border-color: '.esc_attr($car_auto_parts_tp_preloader_color2_option).' !important;';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_preloader_color2_option != false){
$car_auto_parts_tp_theme_css .='.center2 .ring::before{';
	$car_auto_parts_tp_theme_css .='background: '.esc_attr($car_auto_parts_tp_preloader_color2_option).' !important;';
$car_auto_parts_tp_theme_css .='}';
}
if($car_auto_parts_tp_preloader_bg_color_option != false){
$car_auto_parts_tp_theme_css .='.loader{';
	$car_auto_parts_tp_theme_css .='background: '.esc_attr($car_auto_parts_tp_preloader_bg_color_option).';';
$car_auto_parts_tp_theme_css .='}';
}

// footer-bg-color
$car_auto_parts_tp_footer_bg_color_option = get_theme_mod('car_auto_parts_tp_footer_bg_color_option');

if($car_auto_parts_tp_footer_bg_color_option != false){
$car_auto_parts_tp_theme_css .='#footer{';
	$car_auto_parts_tp_theme_css .='background: '.esc_attr($car_auto_parts_tp_footer_bg_color_option).' !important;';
$car_auto_parts_tp_theme_css .='}';
}

// logo tagline color
$car_auto_parts_site_tagline_color = get_theme_mod('car_auto_parts_site_tagline_color');

if($car_auto_parts_site_tagline_color != false){
$car_auto_parts_tp_theme_css .='.logo h1 a, .logo p a{';
$car_auto_parts_tp_theme_css .='color: '.esc_attr($car_auto_parts_site_tagline_color).';';
$car_auto_parts_tp_theme_css .='}';
}

$car_auto_parts_logo_tagline_color = get_theme_mod('car_auto_parts_logo_tagline_color');
if($car_auto_parts_logo_tagline_color != false){
$car_auto_parts_tp_theme_css .='p.site-description{';
$car_auto_parts_tp_theme_css .='color: '.esc_attr($car_auto_parts_logo_tagline_color).';';
$car_auto_parts_tp_theme_css .='}';
}