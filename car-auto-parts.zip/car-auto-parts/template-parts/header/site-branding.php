<?php
/*
 * Displays the header section with logo, site title, tagline, navigation, and contact information.
 */
?>

<div class="headerbox my-2">
    <div class="container header-main">
        <div class="row m-0">
            <!-- Logo Section -->
            <div class="col-lg-3 col-md-4 col-12 logo-col align-self-center">
                <div class="logo text-center text-md-start">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php endif; ?>

                    <?php if (get_theme_mod('car_auto_parts_site_title', 1)) : ?>
                        <?php if (is_front_page() && is_home()) : ?>
                            <p class="text-capitalize mb-0">
                                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a>
                            </p>
                        <?php else : ?>
                            <h1 class="text-capitalize">
                                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a>
                            </h1>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php
                    $car_auto_parts_description = get_bloginfo('description', 'display');
                    if ($car_auto_parts_description || is_customize_preview()) :
                        if (get_theme_mod('car_auto_parts_site_tagline', 1)) :
                            ?>
                            <p class="site-description my-1 text-capitalize"><?php echo esc_html($car_auto_parts_description); ?></p>
                        <?php endif; 
                    endif;
                    ?>
                </div>
            </div>

            <!-- Navigation Section -->
            <div class="col-lg-7 col-md-4 col-12 align-self-center">
                <div class="main-navhead">
                    <div class="menubox">
                        <div class="menu-content">
                            <?php get_template_part('template-parts/navigation/site-nav'); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Header Details Section -->
            <div class="col-lg-2 col-md-4 align-self-center mb-md-0 mb-3">
                <div class="header-details">
                    <!-- Search Bar -->
                    <span class="search-bar me-3">
                        <button type="button" class="open-search" aria-label="<?php esc_attr_e('Open Search', 'car-auto-parts'); ?>">
                            <i class="fas fa-search"></i>
                        </button>
                    </span>

                    <!-- Cart Icon -->
                    <?php if (class_exists('woocommerce')) : ?> 
                        <p class="mb-0">
                            <span class="product-cart text-center position-relative pe-2">
                                <a href="<?php echo esc_url(wc_get_cart_url()); ?>" title="<?php esc_attr_e('Shopping cart', 'car-auto-parts'); ?>">
                                    <i class="fas fa-shopping-bag me-3"></i>
                                </a>
                                <?php 
                                $car_auto_parts_cart_count = WC()->cart->get_cart_contents_count(); 
                                if ($car_auto_parts_cart_count > 0): ?>
                                    <span class="cart-count"><?php echo esc_html($car_auto_parts_cart_count); ?></span>
                                <?php endif; ?>
                            </span>
                        </p>
                    <?php endif; ?>

                    <!-- Share Link -->
                    <?php
                    $car_auto_parts_header_share_link = get_theme_mod('car_auto_parts_header_share_link');
                    if (!empty($car_auto_parts_header_share_link)) : ?>
                        <p class="mb-0">
                            <a target="_blank" href="<?php echo esc_url($car_auto_parts_header_share_link); ?>">
                                <i class="fas fa-share-square"></i>
                                <span class="screen-reader-text"><?php esc_html_e('Share', 'car-auto-parts'); ?></span>
                            </a>
                        </p>
                    <?php endif; ?>
                    
                </div>
            </div>

            <!-- Search Overlay -->
            <div class="search-outer">
                <div class="inner_searchbox w-100 h-100">
                    <?php get_search_form(); ?>
                </div>
                <button type="button" class="search-close"><?php esc_html_e('CLOSE', 'car-auto-parts'); ?></button>
            </div>
        </div>
    </div>
</div>