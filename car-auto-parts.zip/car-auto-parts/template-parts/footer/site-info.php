<?php
/**
 * Displays footer site info
 *
 * @package Car Auto Parts
 * @subpackage car_auto_parts
 */

?>

<div class="site-info">
    <div class="container">
      <p><?php car_auto_parts_credit(); ?> <?php echo esc_html__('By Themespride', 'car-auto-parts'); ?> </p>
    </div>
</div>
