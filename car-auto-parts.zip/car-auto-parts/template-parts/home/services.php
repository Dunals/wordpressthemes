<?php
/**
 * Template part for displaying the services section
 *
 * @package Car Auto Parts
 * @subpackage car_auto_parts
 */

// Get the courses setting.
$car_auto_parts_courses = get_theme_mod('car_auto_parts_courses_setting', '1');

if ($car_auto_parts_courses == '1') {
?>
<section id="courses-offer" class="py-5 px-md-0 px-3">
  <div class="container">
    <div class="text-center main-sec-title">
      <?php if (get_theme_mod('car_auto_parts_offer_section_tittle')) { ?>
        <h2 class="my-2 text-center"><?php echo esc_html(get_theme_mod('car_auto_parts_offer_section_tittle')); ?></h2>
      <?php } ?>
    </div>
    <?php if (get_theme_mod('car_auto_parts_offer_section_text')) { ?>
      <p class="text-center px-md-5 serv-description"><?php echo esc_html(get_theme_mod('car_auto_parts_offer_section_text')); ?></p>
    <?php } ?>
    
    <div class="row mt-4">
      <?php
        // Get the selected post category and number of posts to show.
        $car_auto_parts_post_category = get_theme_mod('car_auto_parts_offer_section_category');
        $car_auto_parts_posts_to_show = get_theme_mod('car_auto_parts_posts_to_show', 3);

        if ($car_auto_parts_post_category) {
          // Query for posts in the selected category.
          $car_auto_parts_page_query = new WP_Query(array(
            'category_name' => esc_html($car_auto_parts_post_category),
            'posts_per_page' => $car_auto_parts_posts_to_show
          ));

          if ($car_auto_parts_page_query->have_posts()) {
            $car_auto_parts_post_count = 0;

            // Loop through the posts.
            while ($car_auto_parts_page_query->have_posts()) : $car_auto_parts_page_query->the_post();
              $car_auto_parts_post_count++;
      ?>
            <div class="col-lg-4 col-md-4 mb-4">
              <div class="cat-inner-box">
                <?php if (has_post_thumbnail()) : ?>
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title_attribute(); ?>"/>
                <?php else : ?>
                    <div class="course-color"></div>
                <?php endif; ?>

                <div class="mainserv-content">
                  <div class="offer-box mb-2">
                    <h3 class="mb-2 pt-3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="serv-tags">
                    <?php
                      // Get and display the post tags (limit to 3).
                      $car_auto_parts_post_tags = get_the_tags();
                      if ($car_auto_parts_post_tags) {
                        $car_auto_parts_tag_count = 0; // Initialize a counter to limit to 3 tags
                        echo '<div class="post-tags">';
                        foreach ($car_auto_parts_post_tags as $tag) {
                          if ($car_auto_parts_tag_count < 3) {
                            echo '<a href="' . esc_url(get_tag_link($tag->term_id)) . '" class="tag-link">' . esc_html($tag->name) . '</a>';
                            // Add "/" separator if it's not the last tag
                            if ($car_auto_parts_tag_count < 2 && $car_auto_parts_tag_count < (count($car_auto_parts_post_tags) - 1)) {
                              echo ' / ';
                            }
                          }
                          $car_auto_parts_tag_count++;
                        }
                        echo '</div>'; // Close post-tags div
                      }
                    ?>
                    </div>
                  </div>

                  <div class="car-info my-lg-3 my-1">
                    <div class="row">
                      <?php if ($car_auto_parts_miles = get_theme_mod('car_auto_parts_car_miles' . $car_auto_parts_post_count)) { ?>
                        <div class="col-lg-4 col-md-4 col-4 align-self-center car-features text-center">
                          <p class="mb-0"><i class="fas fa-car"></i></p>
                          <span class="features-text"><?php echo esc_html($car_auto_parts_miles); ?> <?php esc_html_e('Miles', 'car-auto-parts'); ?></span>
                        </div>
                      <?php } ?>
                      <?php if ($car_auto_parts_fuel_type = get_theme_mod('car_auto_parts_fuel_type' . $car_auto_parts_post_count)) { ?>
                        <div class="col-lg-4 col-md-4 col-4 align-self-center car-features text-center">
                          <p class="mb-0"><i class="fas fa-car"></i></p>
                          <span class="features-text"><?php echo esc_html($car_auto_parts_fuel_type); ?></span>
                        </div>
                      <?php } ?>
                      <?php if ($car_auto_parts_transmission_type = get_theme_mod('car_auto_parts_transmission_type' . $car_auto_parts_post_count)) { ?>
                        <div class="col-lg-4 col-md-4 col-4 align-self-center car-features text-center">
                          <p class="mb-0"><i class="fas fa-cogs"></i></p>
                          <span class="features-text"><?php echo esc_html($car_auto_parts_transmission_type); ?></span>
                        </div>
                      <?php } ?>
                    </div>
                  </div>

                  <hr>

                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-6 align-self-center">
                      <?php if ($car_auto_parts_price = get_theme_mod('car_auto_parts_courses_prices' . $car_auto_parts_post_count)) { ?>
                        <p class="cours-price mb-0"><?php echo esc_html($car_auto_parts_price); ?></p>
                      <?php } ?>
                    </div>
                    <div class="col-lg-6 col-md-6 col-6 text-end align-self-center">
                      <?php 
                      $car_auto_parts_star_rating = get_theme_mod('car_auto_parts_star_rating' . $car_auto_parts_post_count); 
                      if ($car_auto_parts_star_rating) { ?>
                        <div class="star-rating">
                          <i class="fas fa-star"></i>
                          <span class="rate-text"><?php echo esc_html($car_auto_parts_star_rating); ?></span>
                        </div>
                      <?php } ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php endwhile;
          wp_reset_postdata(); // Reset post data after the custom query.
          } else {
            // Optionally display a message if no posts are found.
            echo '<div class="no-postfound">' . esc_html__('No courses found.', 'car-auto-parts') . '</div>';
          }
        }
      ?>
    </div>
  </div>
</section>
<?php 
} // End of the if statement for courses.
?>