<?php

	$car_auto_parts_tp_theme_css = "";

$car_auto_parts_theme_lay = get_theme_mod( 'car_auto_parts_tp_body_layout_settings','Full');
if($car_auto_parts_theme_lay == 'Container'){
$car_auto_parts_tp_theme_css .='body{';
	$car_auto_parts_tp_theme_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
$car_auto_parts_tp_theme_css .='}';
$car_auto_parts_tp_theme_css .='@media screen and (max-width:575px){';
		$car_auto_parts_tp_theme_css .='body{';
			$car_auto_parts_tp_theme_css .='max-width: 100%; padding-right:0px; padding-left: 0px';
		$car_auto_parts_tp_theme_css .='} }';
$car_auto_parts_tp_theme_css .='.page-template-front-page .menubar{';
	$car_auto_parts_tp_theme_css .='position: static;';
$car_auto_parts_tp_theme_css .='}';
$car_auto_parts_tp_theme_css .='.scrolled{';
	$car_auto_parts_tp_theme_css .='width: auto; left:0; right:0;';
$car_auto_parts_tp_theme_css .='}';
}else if($car_auto_parts_theme_lay == 'Container Fluid'){
$car_auto_parts_tp_theme_css .='body{';
	$car_auto_parts_tp_theme_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
$car_auto_parts_tp_theme_css .='}';
$car_auto_parts_tp_theme_css .='@media screen and (max-width:575px){';
		$car_auto_parts_tp_theme_css .='body{';
			$car_auto_parts_tp_theme_css .='max-width: 100%; padding-right:0px; padding-left:0px';
		$car_auto_parts_tp_theme_css .='} }';
$car_auto_parts_tp_theme_css .='.page-template-front-page .menubar{';
	$car_auto_parts_tp_theme_css .='width: 99%';
$car_auto_parts_tp_theme_css .='}';		
$car_auto_parts_tp_theme_css .='.scrolled{';
	$car_auto_parts_tp_theme_css .='width: auto; left:0; right:0;';
$car_auto_parts_tp_theme_css .='}';
}else if($car_auto_parts_theme_lay == 'Full'){
$car_auto_parts_tp_theme_css .='body{';
	$car_auto_parts_tp_theme_css .='max-width: 100%;';
$car_auto_parts_tp_theme_css .='}';
}

$car_auto_parts_scroll_position = get_theme_mod( 'car_auto_parts_scroll_top_position','Right');
if($car_auto_parts_scroll_position == 'Right'){
$car_auto_parts_tp_theme_css .='#return-to-top{';
    $car_auto_parts_tp_theme_css .='right: 20px;';
$car_auto_parts_tp_theme_css .='}';
}else if($car_auto_parts_scroll_position == 'Left'){
$car_auto_parts_tp_theme_css .='#return-to-top{';
    $car_auto_parts_tp_theme_css .='left: 20px;';
$car_auto_parts_tp_theme_css .='}';
}else if($car_auto_parts_scroll_position == 'Center'){
$car_auto_parts_tp_theme_css .='#return-to-top{';
    $car_auto_parts_tp_theme_css .='right: 50%;left: 50%;';
$car_auto_parts_tp_theme_css .='}';
}

    
//Social icon Font size
$car_auto_parts_social_icon_fontsize = get_theme_mod('car_auto_parts_social_icon_fontsize');
	$car_auto_parts_tp_theme_css .='.media-links a i{';
$car_auto_parts_tp_theme_css .='font-size: '.esc_attr($car_auto_parts_social_icon_fontsize).'px;';
$car_auto_parts_tp_theme_css .='}';

// site title font size option
$car_auto_parts_site_title_font_size = get_theme_mod('car_auto_parts_site_title_font_size', 30);{
$car_auto_parts_tp_theme_css .='.logo h1 , .logo p a{';
	$car_auto_parts_tp_theme_css .='font-size: '.esc_attr($car_auto_parts_site_title_font_size).'px;';
$car_auto_parts_tp_theme_css .='}';
}

//site tagline font size option
$car_auto_parts_site_tagline_font_size = get_theme_mod('car_auto_parts_site_tagline_font_size', 15);{
$car_auto_parts_tp_theme_css .='.logo p{';
	$car_auto_parts_tp_theme_css .='font-size: '.esc_attr($car_auto_parts_site_tagline_font_size).'px;';
$car_auto_parts_tp_theme_css .='}';
}

// related post
$car_auto_parts_related_post_mob = get_theme_mod('car_auto_parts_related_post_mob', true);
$car_auto_parts_related_post = get_theme_mod('car_auto_parts_remove_related_post', true);
$car_auto_parts_tp_theme_css .= '.related-post-block {';
if ($car_auto_parts_related_post == false) {
    $car_auto_parts_tp_theme_css .= 'display: none;';
}
$car_auto_parts_tp_theme_css .= '}';
$car_auto_parts_tp_theme_css .= '@media screen and (max-width: 575px) {';
if ($car_auto_parts_related_post == false || $car_auto_parts_related_post_mob == false) {
    $car_auto_parts_tp_theme_css .= '.related-post-block { display: none; }';
}
$car_auto_parts_tp_theme_css .= '}';

//return to header mobile				
$car_auto_parts_return_to_header_mob = get_theme_mod('car_auto_parts_return_to_header_mob', true);
$car_auto_parts_return_to_header = get_theme_mod('car_auto_parts_return_to_header', true);
$car_auto_parts_tp_theme_css .= '.return-to-header{';
if ($car_auto_parts_return_to_header == false) {
    $car_auto_parts_tp_theme_css .= 'display: none;';
}
$car_auto_parts_tp_theme_css .= '}';
$car_auto_parts_tp_theme_css .= '@media screen and (max-width: 575px) {';
if ($car_auto_parts_return_to_header == false || $car_auto_parts_return_to_header_mob == false) {
    $car_auto_parts_tp_theme_css .= '.return-to-header{ display: none; }';
}
$car_auto_parts_tp_theme_css .= '}';


//footer image
$car_auto_parts_footer_widget_image = get_theme_mod('car_auto_parts_footer_widget_image');
if($car_auto_parts_footer_widget_image != false){
$car_auto_parts_tp_theme_css .='#footer{';
	$car_auto_parts_tp_theme_css .='background: url('.esc_attr($car_auto_parts_footer_widget_image).');';
$car_auto_parts_tp_theme_css .='}';
}

// related product
$car_auto_parts_related_product = get_theme_mod('car_auto_parts_related_product',true);
if($car_auto_parts_related_product == false){
$car_auto_parts_tp_theme_css .='.related.products{';
	$car_auto_parts_tp_theme_css .='display: none;';
$car_auto_parts_tp_theme_css .='}';
}

//menu font size
$car_auto_parts_menu_font_size = get_theme_mod('car_auto_parts_menu_font_size', '');{
$car_auto_parts_tp_theme_css .='.main-navigation a, .main-navigation li.page_item_has_children:after,.main-navigation li.menu-item-has-children:after{';
	$car_auto_parts_tp_theme_css .='font-size: '.esc_attr($car_auto_parts_menu_font_size).'px;';
$car_auto_parts_tp_theme_css .='}';
}

// menu text tranform
$car_auto_parts_menu_text_tranform = get_theme_mod( 'car_auto_parts_menu_text_tranform','');
if($car_auto_parts_menu_text_tranform == 'Uppercase'){
$car_auto_parts_tp_theme_css .='.main-navigation a {';
	$car_auto_parts_tp_theme_css .='text-transform: uppercase;';
$car_auto_parts_tp_theme_css .='}';
}else if($car_auto_parts_menu_text_tranform == 'Lowercase'){
$car_auto_parts_tp_theme_css .='.main-navigation a {';
	$car_auto_parts_tp_theme_css .='text-transform: lowercase;';
$car_auto_parts_tp_theme_css .='}';
}
else if($car_auto_parts_menu_text_tranform == 'Capitalize'){
$car_auto_parts_tp_theme_css .='.main-navigation a {';
	$car_auto_parts_tp_theme_css .='text-transform: capitalize;';
$car_auto_parts_tp_theme_css .='}';
}

// patient
// Retrieve the customer review setting from the theme customization options.
$car_auto_parts_customer_review = get_theme_mod('car_auto_parts_customer_review', '');

// Check if the customer review is empty.
if (empty($car_auto_parts_customer_review)) {
    // Initialize the CSS variable if not already done.
    if (!isset($car_auto_parts_tp_theme_css)) {
        $car_auto_parts_tp_theme_css = '';
    }
    
    // Append the necessary CSS to remove padding, border, and border-radius when the review is empty.
    $car_auto_parts_tp_theme_css .= '.customzer-rating {';
    $car_auto_parts_tp_theme_css .= 'padding: 0; border: 0; border-radius: 0;';
    $car_auto_parts_tp_theme_css .= '}';
    // Append the necessary CSS to remove padding, border, and border-radius when the review is empty.
    $car_auto_parts_tp_theme_css .= '.half-width-border-top::before{';
    $car_auto_parts_tp_theme_css .= 'right:0; top:-40px;';
    $car_auto_parts_tp_theme_css .= '}';
}

// Output the CSS using a suitable hook (if necessary).

//slider false
$car_auto_parts_slider_arrows = get_theme_mod('car_auto_parts_slider_arrows',true);
if($car_auto_parts_slider_arrows != true){
$car_auto_parts_tp_theme_css .='.page-template-front-page .headerbox{';
	$car_auto_parts_tp_theme_css .='position:static;border-bottom:1px solid #ccc;';
$car_auto_parts_tp_theme_css .='}';
}

/*------------- Blog Page------------------*/
	$car_auto_parts_post_image_round = get_theme_mod('car_auto_parts_post_image_round', 0);
	if($car_auto_parts_post_image_round != false){
		$car_auto_parts_tp_theme_css .='.blog .box-image img{';
			$car_auto_parts_tp_theme_css .='border-radius: '.esc_attr($car_auto_parts_post_image_round).'px;';
		$car_auto_parts_tp_theme_css .='}';
	}

	$car_auto_parts_post_image_width = get_theme_mod('car_auto_parts_post_image_width', '');
	if($car_auto_parts_post_image_width != false){
		$car_auto_parts_tp_theme_css .='.blog .box-image img{';
			$car_auto_parts_tp_theme_css .='Width: '.esc_attr($car_auto_parts_post_image_width).'px;';
		$car_auto_parts_tp_theme_css .='}';
	}

	$car_auto_parts_post_image_length = get_theme_mod('car_auto_parts_post_image_length', '');
	if($car_auto_parts_post_image_length != false){
		$car_auto_parts_tp_theme_css .='.blog .box-image img{';
			$car_auto_parts_tp_theme_css .='height: '.esc_attr($car_auto_parts_post_image_length).'px;';
		$car_auto_parts_tp_theme_css .='}';
	}
