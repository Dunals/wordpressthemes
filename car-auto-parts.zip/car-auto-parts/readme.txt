=== Car Auto Parts ===
Contributors: ThemesPride
Tags: wide-blocks, block-styles, one-column, two-columns, right-sidebar, left-sidebar, three-columns, four-columns, grid-layout, custom-colors, custom-header, custom-background, custom-menu, custom-logo, editor-style, featured-images, featured-image-header, flexible-header, footer-widgets, full-width-template, rtl-language-support, translation-ready, sticky-post, theme-options, post-formats, threaded-comments, portfolio, e-commerce, blog
Requires at least: 5.0
Tested up to: 6.6
Requires PHP: 5.6
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The Car Car Auto Parts WordPress Theme is a specialized, feature-rich solution designed to create a robust online presence for Car Auto Parts businesses. Whether you're an aftermarket car parts supplier, car accessories retailer, or an Car Auto Parts manufacturer, this theme provides all the tools needed to establish an engaging car parts eCommerce store. Built for businesses that deal in car spare parts, OEM car parts, and performance upgrades, the theme offers an easy way to showcase various car parts, including brake parts, suspension components, car engine parts, and automobile accessories. This theme is tailored for use in car parts stores, auto repair services, and online car parts shops, making it versatile for businesses focused on Car Auto Parts retail or wholesale. Its sleek and modern design, combined with high-quality visual elements, allows you to present car body parts, car lighting systems, and car maintenance products effectively. The visual layout is designed to highlight car parts inventory, giving visitors an easy-to-navigate experience for finding exactly what they need. The Car Car Auto Parts WordPress Theme is fully responsive, ensuring your car parts online store looks great and functions perfectly on any device. With integrated car parts eCommerce features and advanced search options, customers can easily browse car parts for sale, check availability, and make informed purchasing decisions.

Installation

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Car Auto Parts in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Go to # for a guide on how to customize this theme.

== Changelog ==

= 1.0 =
	. Initial version released.

= 1.1 =
	* Added get Started.
	* Added footer link.
	* Implemented one-click demo import functionality.
	* Added a global color option.
	* Updated typography.
	* Added option to set border-radius for post images.
	* Added option to adjust post image height.
	* Added option to adjust post image width.
	* Added option to customize logo title color.
	* Added a color setting for the site tagline.
	* Added settings to customize the 404 page title.
	* Added settings to customize the 404 page text.
	* Resolved CSS issues on the 404 page and the "no results found" search page.
	* Added settings to customize the title on the "no results found" search page.
	* Added settings to customize the text on the "no results found" search page.
	* Added the POT file for translation.

== Resources ==

Car Auto Parts WordPress Theme, Copyright 2024 ThemesPride
Car Auto Parts is distributed under the terms of the GNU GPL

Car Auto Parts WordPress Theme is derived from Twenty Seventeen WordPress Theme, Copyright 2016 WordPress.org
Twenty Seventeen is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Car Auto Parts bundles the following third-party resources:

CSS bootstrap.css
License: bootstrap is licensed under the MIT License
Source: https://github.com/twbs/bootstrap/blob/master/LICENSE

JS bootstrap.js
License: bootstrap is licensed under the MIT License
Source: https://github.com/twbs/bootstrap/blob/master/LICENSE

Font Awesome icons, Copyright Dave Gandy
License: Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License
Source: http://fontawesome.io/

Webfonts Loader
License: https://github.com/WPTT/webfont-loader/blob/master/LICENSE
Source: https://github.com/WPTT/webfont-loader

Owl Carousel v2.3.4 Copyright 2013-2018 David Deutsch
Licensed under: SEE LICENSE IN
Source: https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE

TGMPA, GaryJones Copyright (C) 1989, 1991
License: GNU General Public License v2.0
Source: https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md

Pxhere Images
Image for theme screenshot, Credit grenny
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1446783

Pxhere Images
Image for theme screenshot, Credit grenny
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1075494

Pxhere Images
Image for theme screenshot, Credit grenny
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/168413

Pxhere Images
Image for theme screenshot, Credit grenny
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/697881

Pxhere Images
Image for theme screenshot, Credit grenny
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/334479
