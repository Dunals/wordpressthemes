<?php 
if (isset($_GET['import-demo']) && $_GET['import-demo'] == true) {

    // ------- Create Nav Menu --------
$car_auto_parts_menuname = 'Main Menus';
$car_auto_parts_bpmenulocation = 'primary-menu';
$car_auto_parts_menu_exists = wp_get_nav_menu_object($car_auto_parts_menuname);

if (!$car_auto_parts_menu_exists) {
    $car_auto_parts_menu_id = wp_create_nav_menu($car_auto_parts_menuname);

    // Create Home Page
    $car_auto_parts_home_title = 'Home';
    $car_auto_parts_home = array(
        'post_type' => 'page',
        'post_title' => $car_auto_parts_home_title,
        'post_content' => '',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_slug' => 'home'
    );
    $car_auto_parts_home_id = wp_insert_post($car_auto_parts_home);

    // Assign Home Page Template
    add_post_meta($car_auto_parts_home_id, '_wp_page_template', 'page-template/front-page.php');

    // Update options to set Home Page as the front page
    update_option('page_on_front', $car_auto_parts_home_id);
    update_option('show_on_front', 'page');

    // Add Home Page to Menu
    wp_update_nav_menu_item($car_auto_parts_menu_id, 0, array(
        'menu-item-title' => __('Home', 'car-auto-parts'),
        'menu-item-classes' => 'home',
        'menu-item-url' => home_url('/'),
        'menu-item-status' => 'publish',
        'menu-item-object-id' => $car_auto_parts_home_id,
        'menu-item-object' => 'page',
        'menu-item-type' => 'post_type'
    ));

    // Create About Us Page with Dummy Content
    $car_auto_parts_about_title = 'About Us';
    $car_auto_parts_about_content = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...<br>

             Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br> 

                There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which dont look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text.<br> 

                All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.';
    $car_auto_parts_about = array(
        'post_type' => 'page',
        'post_title' => $car_auto_parts_about_title,
        'post_content' => $car_auto_parts_about_content,
        'post_status' => 'publish',
        'post_author' => 1,
        'post_slug' => 'about-us'
    );
    $car_auto_parts_about_id = wp_insert_post($car_auto_parts_about);

    // Add About Us Page to Menu
    wp_update_nav_menu_item($car_auto_parts_menu_id, 0, array(
        'menu-item-title' => __('About Us', 'car-auto-parts'),
        'menu-item-classes' => 'about-us',
        'menu-item-url' => home_url('/about-us/'),
        'menu-item-status' => 'publish',
        'menu-item-object-id' => $car_auto_parts_about_id,
        'menu-item-object' => 'page',
        'menu-item-type' => 'post_type'
    ));

    // Create Services Page with Dummy Content
    $car_auto_parts_services_title = 'Services';
    $car_auto_parts_services_content = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...<br>

             Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br> 

                There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which dont look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text.<br> 

                All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.';
    $car_auto_parts_services = array(
        'post_type' => 'page',
        'post_title' => $car_auto_parts_services_title,
        'post_content' => $car_auto_parts_services_content,
        'post_status' => 'publish',
        'post_author' => 1,
        'post_slug' => 'services'
    );
    $car_auto_parts_services_id = wp_insert_post($car_auto_parts_services);

    // Add Services Page to Menu
    wp_update_nav_menu_item($car_auto_parts_menu_id, 0, array(
        'menu-item-title' => __('Services', 'car-auto-parts'),
        'menu-item-classes' => 'services',
        'menu-item-url' => home_url('/services/'),
        'menu-item-status' => 'publish',
        'menu-item-object-id' => $car_auto_parts_services_id,
        'menu-item-object' => 'page',
        'menu-item-type' => 'post_type'
    ));

    // Create Pages Page with Dummy Content
    $car_auto_parts_pages_title = 'Pages';
    $car_auto_parts_pages_content = '<h2>Our Pages</h2>
    <p>Explore all the pages we have on our website. Find information about our services, company, and more.</p>';
    $car_auto_parts_pages = array(
        'post_type' => 'page',
        'post_title' => $car_auto_parts_pages_title,
        'post_content' => $car_auto_parts_pages_content,
        'post_status' => 'publish',
        'post_author' => 1,
        'post_slug' => 'pages'
    );
    $car_auto_parts_pages_id = wp_insert_post($car_auto_parts_pages);

    // Add Pages Page to Menu
    wp_update_nav_menu_item($car_auto_parts_menu_id, 0, array(
        'menu-item-title' => __('Pages', 'car-auto-parts'),
        'menu-item-classes' => 'pages',
        'menu-item-url' => home_url('/pages/'),
        'menu-item-status' => 'publish',
        'menu-item-object-id' => $car_auto_parts_pages_id,
        'menu-item-object' => 'page',
        'menu-item-type' => 'post_type'
    ));

    // Create Contact Page with Dummy Content
    $car_auto_parts_contact_title = 'Contact';
    $car_auto_parts_contact_content = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...<br>

             Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br> 

                There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which dont look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text.<br> 

                All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.';
    $car_auto_parts_contact = array(
        'post_type' => 'page',
        'post_title' => $car_auto_parts_contact_title,
        'post_content' => $car_auto_parts_contact_content,
        'post_status' => 'publish',
        'post_author' => 1,
        'post_slug' => 'contact'
    );
    $car_auto_parts_contact_id = wp_insert_post($car_auto_parts_contact);

    // Add Contact Page to Menu
    wp_update_nav_menu_item($car_auto_parts_menu_id, 0, array(
        'menu-item-title' => __('Contact', 'car-auto-parts'),
        'menu-item-classes' => 'contact',
        'menu-item-url' => home_url('/contact/'),
        'menu-item-status' => 'publish',
        'menu-item-object-id' => $car_auto_parts_contact_id,
        'menu-item-object' => 'page',
        'menu-item-type' => 'post_type'
    ));

    // Set the menu location if it's not already set
    if (!has_nav_menu($car_auto_parts_bpmenulocation)) {
        $locations = get_theme_mod('nav_menu_locations'); // Use 'nav_menu_locations' to get locations array
        if (empty($locations)) {
            $locations = array();
        }
        $locations[$car_auto_parts_bpmenulocation] = $car_auto_parts_menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}

        //---Header--//
        set_theme_mod('car_auto_parts_header_share_link', '#');

        // Slider Section
        set_theme_mod('car_auto_parts_slider_arrows', true);
        set_theme_mod('car_auto_parts_slider_short_heading', 'Finding Your Perfect Road Companion');

        set_theme_mod('car_auto_parts_social_media_facebook', '#');
        set_theme_mod('car_auto_parts_social_media_instagram', '#');
        set_theme_mod('car_auto_parts_social_media_twitter', '#');
        set_theme_mod('car_auto_parts_social_media_linkedin', '#');

        for ($i = 1; $i <= 4; $i++) {
            $car_auto_parts_title = 'Cars For Every Journey';

            // Create post object
            $my_post = array(
                'post_title'    => wp_strip_all_tags($car_auto_parts_title),
                'post_status'   => 'publish',
                'post_type'     => 'page',
            );

            // Insert the post into the database
            $post_id = wp_insert_post($my_post);

            // Check for errors when inserting the post
            if (is_wp_error($post_id)) {
                error_log('Error creating slider page: ' . $post_id->get_error_message());
                continue; // Skip to the next iteration if error occurs
            }

            // Set the theme mod for the slider page
            set_theme_mod('car_auto_parts_slider_page' . $i, $post_id);

            // Set the slider image
            $image_url = get_template_directory_uri() . '/assets/images/slider.png';
            $image_id = media_sideload_image($image_url, $post_id, null, 'id');

            // Handle image download errors
            if (!is_wp_error($image_id)) {
                // Set the downloaded image as the post's featured image
                set_post_thumbnail($post_id, $image_id);
            } else {
                error_log('Error downloading slider image: ' . $image_id->get_error_message());
            }
        }


        // Our Services Section //
    set_theme_mod('car_auto_parts_offer_section_tittle', 'Popular Makes');

    set_theme_mod('car_auto_parts_offer_section_text', 'Lorem ipsum dolor sit that amet, consectetur adipiscing elit.');

    set_theme_mod('car_auto_parts_offer_section_category', 'postcategory1');

    set_theme_mod('car_auto_parts_posts_to_show', '3');

    set_theme_mod('car_auto_parts_car_miles1', '100 Miles');
    set_theme_mod('car_auto_parts_car_miles2', '100 Miles');
    set_theme_mod('car_auto_parts_car_miles3', '100 Miles');

    set_theme_mod('car_auto_parts_fuel_type1', 'Petrol');
    set_theme_mod('car_auto_parts_fuel_type2', 'Petrol');
    set_theme_mod('car_auto_parts_fuel_type3', 'Petrol');

    set_theme_mod('car_auto_parts_transmission_type1', 'Automatic');
    set_theme_mod('car_auto_parts_transmission_type2', 'Automatic');
    set_theme_mod('car_auto_parts_transmission_type3', 'Automatic');

    set_theme_mod('car_auto_parts_courses_prices1', '$52,000');
    set_theme_mod('car_auto_parts_courses_prices2', '$52,000');
    set_theme_mod('car_auto_parts_courses_prices3', '$52,000');

    set_theme_mod('car_auto_parts_star_rating1', '4.5');
    set_theme_mod('car_auto_parts_star_rating2', '4.5');
    set_theme_mod('car_auto_parts_star_rating3', '4.5');

    // Define post category names and post titles
    $car_auto_parts_category_names = array('postcategory1');
    $car_auto_parts_title_array = array(
        array("BMW 8-serie 2-door coupe grey", "BMW 8-serie 2-door coupe grey", "BMW 8-serie 2-door coupe grey")
    );

    foreach ($car_auto_parts_category_names as $car_auto_parts_index => $car_auto_parts_category_name) {
        // Create or retrieve the post category term ID
        $car_auto_parts_term = term_exists($car_auto_parts_category_name, 'category');
        if ($car_auto_parts_term === 0 || $car_auto_parts_term === null) {
            // If the term does not exist, create it
            $car_auto_parts_term = wp_insert_term($car_auto_parts_category_name, 'category');
        }
        if (is_wp_error($car_auto_parts_term)) {
            error_log('Error creating category: ' . $car_auto_parts_term->get_error_message());
            continue; // Skip to the next iteration if category creation fails
        }

        for ($car_auto_parts_i = 0; $car_auto_parts_i < 3; $car_auto_parts_i++) {
            // Create post content
            $car_auto_parts_title = $car_auto_parts_title_array[$car_auto_parts_index][$car_auto_parts_i];

            // Create post post object
            $car_auto_parts_my_post = array(
                'post_title'    => wp_strip_all_tags($car_auto_parts_title),
                'post_status'   => 'publish',
                'post_type'     => 'post', // Post type set to 'post'
            );

            // Insert the post into the database
            $car_auto_parts_post_id = wp_insert_post($car_auto_parts_my_post);

            if (is_wp_error($car_auto_parts_post_id)) {
                error_log('Error creating post: ' . $car_auto_parts_post_id->get_error_message());
                continue; // Skip to the next post if creation fails
            }

            // Assign the category to the post
            wp_set_post_categories($car_auto_parts_post_id, array((int)$car_auto_parts_term['term_id']));

            // Handle the featured image using media_sideload_image
            $car_auto_parts_image_url = get_stylesheet_directory_uri() . '/assets/images/post-img' . ($car_auto_parts_i + 1) . '.png';
            $car_auto_parts_image_id = media_sideload_image($car_auto_parts_image_url, $car_auto_parts_post_id, null, 'id');

            if (is_wp_error($car_auto_parts_image_id)) {
                error_log('Error downloading image: ' . $car_auto_parts_image_id->get_error_message());
                continue; // Skip to the next post if image download fails
            }

            // Assign featured image to post
            set_post_thumbnail($car_auto_parts_post_id, $car_auto_parts_image_id);
        }
    }


    }

?>