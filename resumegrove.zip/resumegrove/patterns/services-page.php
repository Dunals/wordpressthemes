<?php
/**
 * Title: Services Page 
 * Slug: resumegrove/services-page
 * Categories: resumegrove
 * Post Types: page, wp_template
 * Keywords: services
 */
?>
<!-- wp:pattern {"slug":"resumegrove/about-me"} /-->
<!-- wp:pattern {"slug":"resumegrove/how-it-works"} /-->
<!-- wp:pattern {"slug":"resumegrove/about"} /-->