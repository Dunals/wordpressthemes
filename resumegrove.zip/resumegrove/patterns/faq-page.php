<?php
/**
 * Title: Faq Page 
 * Slug: resumegrove/faq-page
 * Categories: resumegrove
 * Post Types: page, wp_template
 * Keywords: faq
 */
?>
<!-- wp:pattern {"slug":"resumegrove/faq"} /-->
<!-- wp:pattern {"slug":"resumegrove/cta"} /-->