<?php
/**
 * Title: About Page 
 * Slug: resumegrove/about-page
 * Categories: resumegrove
 * Post Types: page, wp_template
 * Keywords: about
 */
?>
<!-- wp:pattern {"slug":"resumegrove/about"} /-->
<!-- wp:pattern {"slug":"resumegrove/team"} /-->
<!-- wp:pattern {"slug":"resumegrove/testimonials"} /-->