<?php
/**
 * Title: time-to-read
 * Slug: margarethe/time-to-read
 * Categories: hidden
 * Inserter: no
 */
?>

<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:post-time-to-read {"style":{"typography":{"lineHeight":"1.5"}},"fontSize":"small"} /-->

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"1.5"}},"fontSize":"small"} -->
<p class="has-small-font-size" style="line-height:1.5"><?php esc_html_e('read', 'margarethe');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->